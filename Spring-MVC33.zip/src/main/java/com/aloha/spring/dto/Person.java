package com.aloha.spring.dto;

import lombok.Data;

@Data
public class Person {

	private String name;
	private int age;
	
	
}
